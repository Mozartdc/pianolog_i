// src/components/SoundSettingsPanel.tsx

import React, { useState, useCallback, useMemo, useEffect } from 'react';
import { useSoundEngine } from './useSoundEngine';
import { 
  SoundSettings, 
  DEFAULT_SOUND_SETTINGS, 
  SOUND_PRESETS, 
  CATEGORY_LABELS, 
  SoundCategory 
} from './soundTypes';

// Volume slider icons
const SoundOffIcon = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
    <path d="M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z"/>
  </svg>
);

const SoundOnIcon = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
    <path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z"/>
  </svg>
);

const SoundSettingsPanel: React.FC = () => {
  const {
    isInitialized,
    initialize,
    applySettings,
    preview,
    stopAll,
    isPlaying
  } = useSoundEngine();

  const [settings, setSettings] = useState<SoundSettings>(DEFAULT_SOUND_SETTINGS);
  const [selectedCategory, setSelectedCategory] = useState<SoundCategory>('wood');
  const [localSettings, setLocalSettings] = useState(settings);

  // Add some delay before applying changes
  const debouncedApply = useMemo(() => {
    let timer: number;
    return (newSettings: SoundSettings) => {
      clearTimeout(timer);
      timer = window.setTimeout(() => {
        setSettings(newSettings);
      }, 80);
    };
  }, []);

  // Set up the sound engine when component loads
  useEffect(() => {
    if (!isInitialized) {
      initialize();
    }
  }, [isInitialized, initialize]);

  // Update settings when they change
  useEffect(() => {
    if (isInitialized) {
      applySettings(settings);
    }
  }, [settings, isInitialized, applySettings]);

  const handleSettingChange = useCallback(<K extends keyof SoundSettings>(
    key: K,
    value: SoundSettings[K]
  ) => {
    const newSettings = { ...localSettings, [key]: value };
    setLocalSettings(newSettings);
    debouncedApply(newSettings);
  }, [localSettings, debouncedApply]);

  const handlePreview = useCallback((type: 'strong' | 'weak' | 'pattern') => {
    if (isPlaying()) return;

    const options = {
      type: type === 'pattern' ? 'pattern' as const : 'single' as const,
      accent: type === 'strong' ? 'strong' as const : 'weak' as const,
      bars: type === 'pattern' ? 1 : undefined
    };

    preview(options);
  }, [preview, isPlaying]);

  const categoryPresets = SOUND_PRESETS.filter(p => p.category === selectedCategory);

  return (
    <div style={{ padding: '20px 0' }}>
      {/* Category selection tabs */}
      <div style={{ marginBottom: '30px' }}>
        <h3 style={{
          fontSize: '18px',
          fontWeight: '700',
          color: 'var(--text-primary)',
          margin: '0 0 16px 0'
        }}>
          사운드 카테고리
        </h3>
        
        <div style={{
          display: 'flex',
          gap: '8px',
          overflowX: 'auto',
          paddingBottom: '8px'
        }}>
          {Object.entries(CATEGORY_LABELS).map(([category, label]) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category as SoundCategory)}
              style={{
                padding: '8px 16px',
                border: 'none',
                borderRadius: '20px',
                backgroundColor: selectedCategory === category ? 'var(--LIVING_CORAL)' : 'var(--bg-secondary, #f0f0f0)',
                color: selectedCategory === category ? 'white' : 'var(--text-primary)',
                fontSize: '14px',
                fontWeight: '500',
                cursor: 'pointer',
                whiteSpace: 'nowrap',
                transition: 'all 0.2s ease'
              }}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* Sound preset selection */}
      <div style={{ marginBottom: '30px' }}>
        <h3 style={{
          fontSize: '18px',
          fontWeight: '700',
          color: 'var(--text-primary)',
          margin: '0 0 16px 0'
        }}>
          사운드 선택
        </h3>

        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))',
          gap: '12px'
        }}>
          {categoryPresets.map(preset => (
            <button
              key={preset.id}
              onClick={() => handleSettingChange('presetId', preset.id)}
              style={{
                padding: '16px 12px',
                border: '2px solid',
                borderColor: localSettings.presetId === preset.id ? 'var(--LIVING_CORAL)' : 'var(--DARK_GRAY)',
                borderRadius: '12px',
                backgroundColor: localSettings.presetId === preset.id ? 'var(--LIVING_CORAL)' : 'var(--bg-secondary, #f8f9fa)',
                color: localSettings.presetId === preset.id ? 'white' : 'var(--text-primary)',
                cursor: 'pointer',
                textAlign: 'left',
                transition: 'all 0.2s ease'
              }}
            >
              <div style={{ fontWeight: '600', marginBottom: '4px' }}>
                {preset.name}
              </div>
              <div style={{ 
                fontSize: '12px', 
                opacity: localSettings.presetId === preset.id ? 0.9 : 0.7,
                lineHeight: '1.3'
              }}>
                {preset.description}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Volume control */}
      <div style={{ marginBottom: '30px' }}>
        <h3 style={{
          fontSize: '18px',
          fontWeight: '700',
          color: 'var(--text-primary)',
          margin: '0 0 16px 0'
        }}>
          볼륨 조절
        </h3>

        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '16px',
          padding: '20px',
          borderRadius: '12px',
          backgroundColor: 'var(--bg-secondary, #f8f9fa)',
          border: '1px solid var(--DARK_GRAY)'
        }}>
          <div style={{ opacity: localSettings.volume === 0 ? 1 : 0.4 }}>
            <SoundOffIcon />
          </div>
          
          <div style={{ flex: 1, position: 'relative' }}>
            <input
              type="range"
              min={0}
              max={1}
              step={0.01}
              value={localSettings.volume}
              onChange={(e) => handleSettingChange('volume', parseFloat(e.target.value))}
              style={{
                width: '100%',
                height: '6px',
                borderRadius: '3px',
                background: `linear-gradient(to right, var(--LIVING_CORAL) ${localSettings.volume * 100}%, var(--DARK_GRAY) ${localSettings.volume * 100}%)`,
                outline: 'none',
                appearance: 'none',
                cursor: 'pointer'
              }}
            />
            <style>
              {`
                input[type="range"]::-webkit-slider-thumb {
                  appearance: none;
                  width: 20px;
                  height: 20px;
                  border-radius: 50%;
                  background: var(--LIVING_CORAL);
                  cursor: pointer;
                  box-shadow: 0 2px 4px rgba(0,0,0,0.2);
                }
                input[type="range"]::-moz-range-thumb {
                  width: 20px;
                  height: 20px;
                  border-radius: 50%;
                  background: var(--LIVING_CORAL);
                  cursor: pointer;
                  border: none;
                  box-shadow: 0 2px 4px rgba(0,0,0,0.2);
                }
              `}
            </style>
          </div>
          
          <div style={{ opacity: localSettings.volume > 0 ? 1 : 0.4 }}>
            <SoundOnIcon />
          </div>
          
          <div style={{
            minWidth: '48px',
            fontSize: '16px',
            fontWeight: '600',
            color: 'var(--text-primary)',
            textAlign: 'center'
          }}>
            {Math.round(localSettings.volume * 100)}%
          </div>
        </div>
      </div>

      {/* Accent multiplier */}
      <div style={{ marginBottom: '30px' }}>
        <h3 style={{
          fontSize: '18px',
          fontWeight: '700',
          color: 'var(--text-primary)',
          margin: '0 0 16px 0'
        }}>
          강박 강조
        </h3>

        <div style={{
          padding: '20px',
          borderRadius: '12px',
          backgroundColor: 'var(--bg-secondary, #f8f9fa)',
          border: '1px solid var(--DARK_GRAY)'
        }}>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '16px'
          }}>
            <span style={{ fontSize: '14px', color: 'var(--text-secondary)' }}>1.0×</span>
            
            <input
              type="range"
              min={1}
              max={2}
              step={0.1}
              value={localSettings.accentGain}
              onChange={(e) => handleSettingChange('accentGain', parseFloat(e.target.value))}
              style={{
                flex: 1,
                height: '6px',
                borderRadius: '3px',
                background: `linear-gradient(to right, var(--LIVING_CORAL) ${(localSettings.accentGain - 1) * 100}%, var(--DARK_GRAY) ${(localSettings.accentGain - 1) * 100}%)`,
                outline: 'none',
                appearance: 'none',
                cursor: 'pointer'
              }}
            />
            
            <span style={{ fontSize: '14px', color: 'var(--text-secondary)' }}>2.0×</span>
            
            <div style={{
              minWidth: '48px',
              fontSize: '16px',
              fontWeight: '600',
              color: 'var(--text-primary)',
              textAlign: 'center'
            }}>
              {localSettings.accentGain.toFixed(1)}×
            </div>
          </div>
        </div>
      </div>

      {/* Preview buttons */}
      <div style={{ marginBottom: '30px' }}>
        <h3 style={{
          fontSize: '18px',
          fontWeight: '700',
          color: 'var(--text-primary)',
          margin: '0 0 16px 0'
        }}>
          미리듣기
        </h3>

        <div style={{
          display: 'flex',
          gap: '12px',
          flexWrap: 'wrap'
        }}>
          <button
            onClick={() => handlePreview('strong')}
            disabled={isPlaying()}
            style={{
              padding: '12px 20px',
              backgroundColor: isPlaying() ? 'var(--DARK_GRAY)' : 'var(--TURQUOISE)',
              color: 'white',
              border: 'none',
              borderRadius: '8px',
              fontSize: '14px',
              fontWeight: '600',
              cursor: isPlaying() ? 'not-allowed' : 'pointer',
              opacity: isPlaying() ? 0.5 : 1,
              transition: 'all 0.2s ease'
            }}
          >
            강박 미리듣기
          </button>
          
          <button
            onClick={() => handlePreview('weak')}
            disabled={isPlaying()}
            style={{
              padding: '12px 20px',
              backgroundColor: isPlaying() ? 'var(--DARK_GRAY)' : 'var(--VERY_PERI)',
              color: 'white',
              border: 'none',
              borderRadius: '8px',
              fontSize: '14px',
              fontWeight: '600',
              cursor: isPlaying() ? 'not-allowed' : 'pointer',
              opacity: isPlaying() ? 0.5 : 1,
              transition: 'all 0.2s ease'
            }}
          >
            약박 미리듣기
          </button>
          
          <button
            onClick={() => handlePreview('pattern')}
            disabled={isPlaying()}
            style={{
              padding: '12px 20px',
              backgroundColor: isPlaying() ? 'var(--DARK_GRAY)' : 'var(--LIVING_CORAL)',
              color: 'white',
              border: 'none',
              borderRadius: '8px',
              fontSize: '14px',
              fontWeight: '600',
              cursor: isPlaying() ? 'not-allowed' : 'pointer',
              opacity: isPlaying() ? 0.5 : 1,
              transition: 'all 0.2s ease'
            }}
          >
            패턴 미리듣기
          </button>

          <button
            onClick={stopAll}
            style={{
              padding: '12px 20px',
              backgroundColor: 'var(--VIVA_MAGENTA)',
              color: 'white',
              border: 'none',
              borderRadius: '8px',
              fontSize: '14px',
              fontWeight: '600',
              cursor: 'pointer',
              transition: 'all 0.2s ease'
            }}
          >
            정지
          </button>
        </div>
      </div>
    </div>
  );
};

export default SoundSettingsPanel;