// src/components/SettingsOverlay.tsx

import React from 'react';
import SoundSettingsPanel from './SoundSettingsPanel';

interface SettingsOverlayProps {
  isOpen: boolean;
  onClose: () => void;
}

const SettingsOverlay: React.FC<SettingsOverlayProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'var(--bg-primary)',
        zIndex: 2000,
        animation: 'slideInFromRight 0.3s ease-out',
        fontFamily: 'var(--FONT_FAMILY)',
        display: 'flex',
        flexDirection: 'column'
      }}
    >
      <style>
        {`
          @keyframes slideInFromRight {
            from {
              transform: translateX(100%);
            }
            to {
              transform: translateX(0);
            }
          }
        `}
      </style>

      {/* Header area */}
      <div style={{
        height: '80px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 20px',
        borderBottom: '1px solid var(--DARK_GRAY)',
        backgroundColor: 'var(--bg-primary)',
        boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)'
      }}>
        <h1 style={{
          fontSize: '28px',
          fontWeight: '900',
          color: 'var(--text-primary)',
          margin: 0,
          fontFamily: 'var(--FONT_FAMILY)'
        }}>
          설정
        </h1>
        
        {/* X button is omitted here since HamburgerButton is above the overlay */}
      </div>

      {/* Tab area */}
      <div style={{
        padding: '0 20px',
        borderBottom: '1px solid var(--DARK_GRAY)',
        backgroundColor: 'var(--bg-primary)'
      }}>
        <div style={{
          display: 'flex',
          gap: '0',
          height: '50px'
        }}>
          <button
            style={{
              flex: 1,
              height: '100%',
              border: 'none',
              backgroundColor: 'var(--LIVING_CORAL)',
              color: 'white',
              fontSize: '16px',
              fontWeight: '600',
              fontFamily: 'var(--FONT_FAMILY)',
              cursor: 'pointer',
              borderBottom: '3px solid var(--LIVING_CORAL)'
            }}
          >
            사운드
          </button>
          
          <button
            style={{
              flex: 1,
              height: '100%',
              border: 'none',
              backgroundColor: 'transparent',
              color: 'var(--text-secondary)',
              fontSize: '16px',
              fontWeight: '600',
              fontFamily: 'var(--FONT_FAMILY)',
              cursor: 'pointer',
              borderBottom: '3px solid transparent',
              opacity: 0.5
            }}
            disabled
          >
            화면
          </button>
          
          <button
            style={{
              flex: 1,
              height: '100%',
              border: 'none',
              backgroundColor: 'transparent',
              color: 'var(--text-secondary)',
              fontSize: '16px',
              fontWeight: '600',
              fontFamily: 'var(--FONT_FAMILY)',
              cursor: 'pointer',
              borderBottom: '3px solid transparent',
              opacity: 0.5
            }}
            disabled
          >
            고급
          </button>
        </div>
      </div>

      {/* Content area */}
      <div style={{
        flex: 1,
        overflowY: 'auto',
        padding: '0 20px',
        paddingBottom: '100px' // bottom spacing
      }}>
        <SoundSettingsPanel />
      </div>
    </div>
  );
};

export default SettingsOverlay;