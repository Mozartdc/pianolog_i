// src/components/SoundBank.ts

import { AudioContextManager } from './AudioContextManager';
import { SoundGenerator } from './SoundGenerator';
import { AudioError, Result, SoundPreset, SOUND_PRESETS } from './soundTypes';

export class SoundBank {
  private audioContextManager: AudioContextManager;
  private soundGenerator: SoundGenerator | null = null;
  private audioBufferCache: Map<string, AudioBuffer> = new Map();
  private loadingPromises: Map<string, Promise<Result<AudioBuffer>>> = new Map();

  constructor() {
    this.audioContextManager = AudioContextManager.getInstance();
  }

  async initialize(): Promise<Result<void>> {
    const contextResult = await this.audioContextManager.ensureContext();
    if (!contextResult.success) {
      return { 
        success: false, 
        error: (contextResult as { success: false; error: any }).error 
      };
    }

    this.soundGenerator = new SoundGenerator(contextResult.data);
    return { success: true, data: undefined };
  }

  async loadSound(presetId: string): Promise<Result<AudioBuffer>> {
    const cached = this.audioBufferCache.get(presetId);
    if (cached) {
      return { success: true, data: cached };
    }

    const loadingPromise = this.loadingPromises.get(presetId);
    if (loadingPromise) {
      return loadingPromise;
    }

    const preset = SOUND_PRESETS.find(p => p.id === presetId);
    if (!preset) {
      return {
        success: false,
        error: AudioError.InvalidSettings
      };
    }

    const promise = this.loadSoundInternal(preset);
    this.loadingPromises.set(presetId, promise);

    const result = await promise;
    this.loadingPromises.delete(presetId);

    if (result.success) {
      this.audioBufferCache.set(presetId, result.data);
    }

    return result;
  }

  async preloadBasicSounds(): Promise<Result<void>> {
    const basicPresets = ['wood_block', 'beep', 'click', 'mechanical'];
    const loadPromises = basicPresets.map(presetId => this.loadSound(presetId));
    
    try {
      const results = await Promise.allSettled(loadPromises);
      
      const failures = results
        .filter((result, index) => result.status === 'rejected' || 
                (result.status === 'fulfilled' && !result.value.success))
        .map((_, index) => basicPresets[index]);

      if (failures.length > 0) {
        console.warn('Failed to preload some sounds:', failures);
      }

      return { success: true, data: undefined };
    } catch (error) {
      console.error('Failed to preload basic sounds:', error);
      return {
        success: false,
        error: AudioError.FileLoadFailed
      };
    }
  }

  getCachedSound(presetId: string): AudioBuffer | null {
    return this.audioBufferCache.get(presetId) || null;
  }

  clearCache(): void {
    this.audioBufferCache.clear();
    this.loadingPromises.clear();
  }

  getCacheInfo(): {
    cachedSounds: string[];
    loadingSounds: string[];
    cacheSize: number;
  } {
    return {
      cachedSounds: Array.from(this.audioBufferCache.keys()),
      loadingSounds: Array.from(this.loadingPromises.keys()),
      cacheSize: this.audioBufferCache.size
    };
  }

  private async loadSoundInternal(preset: SoundPreset): Promise<Result<AudioBuffer>> {
    if (!this.soundGenerator) {
      return {
        success: false,
        error: AudioError.ContextCreationFailed
      };
    }

    try {
      if (preset.audioFile) {
        return await this.loadAudioFile(preset.audioFile);
      } else {
        return this.generateDynamicSound(preset);
      }
    } catch (error) {
      console.error(`Failed to load sound ${preset.id}:`, error);
      return {
        success: false,
        error: AudioError.FileLoadFailed
      };
    }
  }

  private generateDynamicSound(preset: SoundPreset): Result<AudioBuffer> {
    if (!this.soundGenerator) {
      return {
        success: false,
        error: AudioError.ContextCreationFailed
      };
    }

    const soundParams = this.getSoundParams(preset.id);
    
    return this.soundGenerator.generateSoundByType(
      soundParams.type,
      soundParams.options
    );
  }

  private async loadAudioFile(filePath: string): Promise<Result<AudioBuffer>> {
    const contextResult = await this.audioContextManager.ensureContext();
    if (!contextResult.success) {
      return { 
        success: false, 
        error: (contextResult as { success: false; error: any }).error 
      };
    }

    const context = contextResult.data;

    try {
      const response = await fetch(filePath);
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const arrayBuffer = await response.arrayBuffer();
      const audioBuffer = await context.decodeAudioData(arrayBuffer);

      return { success: true, data: audioBuffer };
    } catch (error) {
      console.error(`Failed to load audio file ${filePath}:`, error);
      return {
        success: false,
        error: AudioError.FileLoadFailed
      };
    }
  }

  private getSoundParams(presetId: string): {
    type: 'beep' | 'click' | 'wood' | 'metallic';
    options: {
      frequency?: number;
      duration?: number;
      brightness?: number;
    };
  } {
    switch (presetId) {
      case 'beep':
        return {
          type: 'beep',
          options: { frequency: 800, duration: 0.1 }
        };
      case 'click':
        return {
          type: 'click',
          options: { frequency: 1200, duration: 0.05 }
        };
      case 'wood_block':
        return {
          type: 'wood',
          options: { frequency: 400, duration: 0.15 }
        };
      case 'wood_clap':
        return {
          type: 'wood',
          options: { frequency: 600, duration: 0.12 }
        };
      case 'tambourine':
        return {
          type: 'metallic',
          options: { frequency: 800, duration: 0.2, brightness: 1.5 }
        };
      case 'xylophone':
        return {
          type: 'metallic',
          options: { frequency: 1000, duration: 0.3, brightness: 2.0 }
        };
      case 'marimba':
        return {
          type: 'metallic',
          options: { frequency: 600, duration: 0.4, brightness: 0.8 }
        };
      default:
        return {
          type: 'beep',
          options: { frequency: 800, duration: 0.1 }
        };
    }
  }

  dispose(): void {
    this.clearCache();
    this.soundGenerator = null;
  }
}