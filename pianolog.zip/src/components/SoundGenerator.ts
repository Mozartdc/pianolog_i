// src/components/SoundGenerator.ts

import { AudioError, Result } from './soundTypes';

export class SoundGenerator {
  private context: AudioContext;

  constructor(context: AudioContext) {
    this.context = context;
  }

  generateBeepSound(frequency: number = 800, duration: number = 0.1): Result<AudioBuffer> {
    try {
      const sampleRate = this.context.sampleRate;
      const frameCount = Math.floor(duration * sampleRate);
      const buffer = this.context.createBuffer(1, frameCount, sampleRate);
      const channelData = buffer.getChannelData(0);

      const attackTime = 0.01;
      const decayTime = 0.02;
      const sustainLevel = 0.6;
      const releaseTime = duration - attackTime - decayTime;

      const attackSamples = Math.floor(attackTime * sampleRate);
      const decaySamples = Math.floor(decayTime * sampleRate);
      const releaseSamples = Math.floor(releaseTime * sampleRate);

      for (let i = 0; i < frameCount; i++) {
        const time = i / sampleRate;
        let amplitude: number;

        if (i < attackSamples) {
          amplitude = i / attackSamples;
        } else if (i < attackSamples + decaySamples) {
          const decayProgress = (i - attackSamples) / decaySamples;
          amplitude = 1 - (decayProgress * (1 - sustainLevel));
        } else if (i < frameCount - releaseSamples) {
          amplitude = sustainLevel;
        } else {
          const releaseProgress = (i - (frameCount - releaseSamples)) / releaseSamples;
          amplitude = sustainLevel * (1 - releaseProgress);
        }

        channelData[i] = Math.sin(2 * Math.PI * frequency * time) * amplitude * 0.3;
      }

      return { success: true, data: buffer };
    } catch (error) {
      console.error('Failed to generate beep sound:', error);
      return { 
        success: false, 
        error: AudioError.NodeCreationFailed 
      };
    }
  }

  generateClickSound(frequency: number = 1200, duration: number = 0.05): Result<AudioBuffer> {
    try {
      const sampleRate = this.context.sampleRate;
      const frameCount = Math.floor(duration * sampleRate);
      const buffer = this.context.createBuffer(1, frameCount, sampleRate);
      const channelData = buffer.getChannelData(0);

      const noiseDecay = 0.95;
      let noiseValue = 0;

      for (let i = 0; i < frameCount; i++) {
        const time = i / sampleRate;
        const envelope = Math.exp(-time * 50);

        const whiteNoise = (Math.random() * 2 - 1);
        noiseValue = noiseValue * noiseDecay + whiteNoise * (1 - noiseDecay);

        const toneComponent = Math.sin(2 * Math.PI * frequency * time) * 0.3;
        const clickComponent = Math.sin(2 * Math.PI * frequency * 2 * time) * 0.1;

        channelData[i] = (noiseValue * 0.6 + toneComponent + clickComponent) * envelope * 0.5;
      }

      return { success: true, data: buffer };
    } catch (error) {
      console.error('Failed to generate click sound:', error);
      return { 
        success: false, 
        error: AudioError.NodeCreationFailed 
      };
    }
  }

  generateWoodSound(pitch: number = 400, duration: number = 0.15): Result<AudioBuffer> {
    try {
      const sampleRate = this.context.sampleRate;
      const frameCount = Math.floor(duration * sampleRate);
      const buffer = this.context.createBuffer(1, frameCount, sampleRate);
      const channelData = buffer.getChannelData(0);

      for (let i = 0; i < frameCount; i++) {
        const time = i / sampleRate;
        
        const attackEnv = Math.exp(-time * 80);
        const resonanceEnv = Math.exp(-time * 15) * Math.sin(2 * Math.PI * 3 * time);
        
        const fundamental = Math.sin(2 * Math.PI * pitch * time);
        const harmonic2 = Math.sin(2 * Math.PI * pitch * 1.59 * time) * 0.7;
        const harmonic3 = Math.sin(2 * Math.PI * pitch * 2.13 * time) * 0.4;
        const harmonic4 = Math.sin(2 * Math.PI * pitch * 2.67 * time) * 0.2;
        
        const noise = (Math.random() * 2 - 1) * 0.1 * attackEnv;
        
        const mixedSignal = fundamental + harmonic2 + harmonic3 + harmonic4 + noise;
        channelData[i] = mixedSignal * (attackEnv * 0.7 + resonanceEnv * 0.3) * 0.4;
      }

      return { success: true, data: buffer };
    } catch (error) {
      console.error('Failed to generate wood sound:', error);
      return { 
        success: false, 
        error: AudioError.NodeCreationFailed 
      };
    }
  }

  generateMetallicSound(
    fundamentalFreq: number = 800, 
    duration: number = 0.2,
    brightness: number = 1.0
  ): Result<AudioBuffer> {
    try {
      const sampleRate = this.context.sampleRate;
      const frameCount = Math.floor(duration * sampleRate);
      const buffer = this.context.createBuffer(1, frameCount, sampleRate);
      const channelData = buffer.getChannelData(0);

      for (let i = 0; i < frameCount; i++) {
        const time = i / sampleRate;
        
        const mainEnv = Math.exp(-time * 8);
        const shimmerEnv = Math.exp(-time * 3) * (1 + Math.sin(2 * Math.PI * 7 * time) * 0.3);
        
        const partials = [
          { freq: fundamentalFreq, amp: 1.0 },
          { freq: fundamentalFreq * 1.618, amp: 0.8 },
          { freq: fundamentalFreq * 2.236, amp: 0.6 },
          { freq: fundamentalFreq * 3.141, amp: 0.4 },
          { freq: fundamentalFreq * 4.472, amp: 0.2 },
        ];
        
        let signal = 0;
        partials.forEach(partial => {
          const phase = 2 * Math.PI * partial.freq * time;
          signal += Math.sin(phase) * partial.amp * brightness;
        });
        
        const metalNoise = (Math.random() * 2 - 1) * 0.05 * mainEnv * brightness;
        
        channelData[i] = (signal + metalNoise) * mainEnv * shimmerEnv * 0.3;
      }

      return { success: true, data: buffer };
    } catch (error) {
      console.error('Failed to generate metallic sound:', error);
      return { 
        success: false, 
        error: AudioError.NodeCreationFailed 
      };
    }
  }

  generateSoundByType(
    type: 'beep' | 'click' | 'wood' | 'metallic',
    options: {
      frequency?: number;
      duration?: number;
      brightness?: number;
    } = {}
  ): Result<AudioBuffer> {
    const {
      frequency = 800,
      duration = 0.1,
      brightness = 1.0
    } = options;

    switch (type) {
      case 'beep':
        return this.generateBeepSound(frequency, duration);
      case 'click':
        return this.generateClickSound(frequency, duration);
      case 'wood':
        return this.generateWoodSound(frequency, duration);
      case 'metallic':
        return this.generateMetallicSound(frequency, duration, brightness);
      default:
        return {
          success: false,
          error: AudioError.InvalidSettings
        };
    }
  }
}