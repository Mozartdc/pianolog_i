import React, { useEffect, useState, useRef } from "react";
import { useLocation } from "react-router-dom";
import { MCentralControls as DialComponent } from '../components/MCentralDial';
import MTempoVisualizer from '../components/MTempoVisualizer';
import TimeSignatureButton from '../components/TimeSignatureButton';
import TimeSignatureModal from '../components/TimeSignatureModal';
import NoteSubdivisionButton from '../components/NoteSubdivisionButton';
import NoteSubdivisionModal from '../components/NoteSubdivisionModal';
import TapTempoButton from '../components/TapTempoButton';
import RhythmTrainingButton from '../components/RhythmTrainingButton';
import RhythmTrainingModal from '../components/RhythmTrainingModal';
import RhythmSettingModal from '../components/RhythmSettingModal';
import HamburgerButton from '../components/HamburgerButton';
import SoundSettingsPanel from '../components/SoundSettingsPanel';
import { useMetronomeStore, TimeSignature } from '../components/useMetronomeStore';
import { useRhythmTraining, RhythmTrainingMode } from '../components/useRhythmTraining';
import { MetronomeEngine, TapTempo } from '../components/MetronomeEngine';

function Metronome() {
  const location = useLocation();
  
  const {
    bpm,
    isPlaying,
    currentBeat,
    timeSignature,
    setBpm,
    setTimeSignature,
    setCurrentBeat,
    setIsPlaying,
    getBeatPattern
  } = useMetronomeStore();

  const {
    activeMode,
    songLength,
    incrementalTempo,
    mutePattern,
    setActiveMode,
    setSongLengthSettings,
    setIncrementalTempoSettings,
    setMutePatternSettings,
    getStatusText,
    registerBPMChangeCallback,
    registerStopCallback,
    isMuted
  } = useRhythmTraining();

  // MetronomeEngine and TapTempo instances
  const engineRef = useRef<MetronomeEngine | null>(null);
  const tapTempoRef = useRef<TapTempo | null>(null);

  // Modal states
  const [isTimeSignatureModalOpen, setIsTimeSignatureModalOpen] = useState(false);
  const [isNoteSubdivisionModalOpen, setIsNoteSubdivisionModalOpen] = useState(false);
  const [isRhythmTrainingModalOpen, setIsRhythmTrainingModalOpen] = useState(false);
  const [isRhythmSettingModalOpen, setIsRhythmSettingModalOpen] = useState(false);
  const [selectedSettingMode, setSelectedSettingMode] = useState<RhythmTrainingMode>('none');
  
  // Sound settings panel state
  const [isSoundPanelOpen, setIsSoundPanelOpen] = useState(false);

  // Rhythm subdivision related state
  const [selectedRhythmId, setSelectedRhythmId] = useState('one_beat');
  const rhythmSubdivBtnRef = useRef<HTMLButtonElement | null>(null);

// Initialize MetronomeEngine instances (without audio initialization)
useEffect(() => {
  console.log('useEffect 시작됨 - 메트로놈 엔진 생성 중...');
  
  try {
    const engine = new MetronomeEngine();
    console.log('MetronomeEngine 생성됨:', engine);
    
    const tapTempo = new TapTempo();
    console.log('TapTempo 생성됨:', tapTempo);
    
    // Set up callbacks
    engine.setCallbacks({
      onBeatChange: (beat: number) => {
        console.log('박자 변경:', beat);
        setCurrentBeat(beat);
      },
      onBPMChange: (newBpm: number) => {
        console.log('BPM 변경:', newBpm);
        setBpm(newBpm);
      },
      onStop: () => {
        console.log('메트로놈 정지됨');
        setIsPlaying(false);
      }
    });

    engineRef.current = engine;
    tapTempoRef.current = tapTempo;
    
    console.log('engineRef.current 할당됨:', engineRef.current);
    console.log('메트로놈 엔진 인스턴스 생성 완료');
  } catch (error) {
    console.error('엔진 생성 중 오류:', error);
  }

  // Cleanup
  return () => {
    console.log('cleanup 실행됨');
    if (engineRef.current) {
      engineRef.current.dispose();
    }
  };
}, []);

  // Update engine when configuration changes
  useEffect(() => {
    if (engineRef.current) {
      engineRef.current.updateConfig({
        bpm,
        timeSignature,
        rhythmPatternId: selectedRhythmId,
        isMuted
      });
    }
  }, [bpm, timeSignature, selectedRhythmId, isMuted]);

  // Prevent scrolling
  useEffect(() => {
    if (location.pathname === '/metronome') {
      const originalBodyStyle = document.body.style.cssText;
      document.body.style.position = 'fixed';
      document.body.style.width = '100%';
      document.body.style.top = '0';
      document.body.style.left = '0';
      document.body.style.right = '0';

      return () => {
        document.body.style.cssText = originalBodyStyle;
      };
    }
  }, [location.pathname]);

  // Register rhythm training callbacks
  useEffect(() => {
    registerBPMChangeCallback((newBpm: number) => {
      setBpm(newBpm);
      if (engineRef.current) {
        engineRef.current.updateConfig({ bpm: newBpm });
      }
    });
    
    registerStopCallback(() => {
      handleTogglePlay();
    });
  }, [setBpm, registerBPMChangeCallback, registerStopCallback]);

  const commonFontStyle = {
    fontFamily: "var(--FONT_FAMILY)",
    WebkitFontSmoothing: "antialiased" as const,
    MozOsxFontSmoothing: "grayscale" as const,
  };

  // Main play/stop handler with lazy initialization
  const handleTogglePlay = async () => {
    if (!engineRef.current) {
      console.error('메트로놈 엔진이 생성되지 않았습니다');
      return;
    }

    try {
      if (isPlaying) {
        engineRef.current.stop();
        setIsPlaying(false);
      } else {
        // Initialize engine only when user first clicks (user gesture required)
        console.log('첫 재생 시도 - 엔진 초기화 중...');
        await engineRef.current.initialize();
        
        // Apply current configuration
        engineRef.current.updateConfig({
          bpm,
          timeSignature,
          rhythmPatternId: selectedRhythmId,
          isMuted
        });
        
        await engineRef.current.start();
        setIsPlaying(true);
        console.log('메트로놈 시작됨');
      }
    } catch (error) {
      console.error('메트로놈 재생/정지 실패:', error);
      alert('메트로놈을 시작할 수 없습니다. 오디오 권한을 확인해주세요.');
    }
  };

  // BPM change handler
  const handleBpmChange = (newBpm: number) => {
    setBpm(newBpm);
  };

  // Time signature handlers
  const handleTimeSignatureClick = () => {
    setIsTimeSignatureModalOpen(true);
    setIsNoteSubdivisionModalOpen(false);
    setIsRhythmTrainingModalOpen(false);
    setIsRhythmSettingModalOpen(false);
  };

  const handleTimeSignatureConfirm = (signature: TimeSignature) => {
    setTimeSignature(signature);
    setCurrentBeat(0);
  };

  // Note subdivision handlers
  const handleNoteSubdivisionClick = () => {
    setIsNoteSubdivisionModalOpen(true);
    setIsTimeSignatureModalOpen(false);
    setIsRhythmTrainingModalOpen(false);
    setIsRhythmSettingModalOpen(false);
  };

  const handleRhythmSelect = (rhythmId: string) => {
    setSelectedRhythmId(rhythmId);
    console.log('리듬 패턴 선택:', rhythmId);
  };

  // Rhythm training handlers
  const handleRhythmTrainingClick = () => {
    setIsRhythmTrainingModalOpen(true);
    setIsTimeSignatureModalOpen(false);
    setIsNoteSubdivisionModalOpen(false);
    setIsRhythmSettingModalOpen(false);
  };

  const handleRhythmModeSelect = (mode: RhythmTrainingMode) => {
    setIsRhythmTrainingModalOpen(false);
    
    if (mode === 'none') {
      setActiveMode('none');
      return;
    }
    
    setTimeout(() => {
      setSelectedSettingMode(mode);
      setIsRhythmSettingModalOpen(true);
    }, 100);
  };

  const handleRhythmSettingComplete = () => {
    if (selectedSettingMode !== 'none') {
      setActiveMode(selectedSettingMode);
    }
  };

  const handleSongLengthChange = (settings: typeof songLength) => {
    setSongLengthSettings(settings);
    handleRhythmSettingComplete();
  };

  const handleIncrementalTempoChange = (settings: typeof incrementalTempo) => {
    setIncrementalTempoSettings(settings);
    handleRhythmSettingComplete();
  };

  const handleMutePatternChange = (settings: typeof mutePattern) => {
    setMutePatternSettings(settings);
    handleRhythmSettingComplete();
  };

  // Tap tempo handler
  const handleTapTempoClick = () => {
    if (!tapTempoRef.current) return;

    const calculatedBpm = tapTempoRef.current.tap();
    if (calculatedBpm) {
      setBpm(calculatedBpm);
      console.log('탭 템포로 BPM 설정:', calculatedBpm);
    } else {
      console.log('탭 템포 계산 중... (탭 횟수:', tapTempoRef.current.getTapCount(), ')');
    }
  };

  const handleModalClose = () => {
    setIsTimeSignatureModalOpen(false);
    setIsNoteSubdivisionModalOpen(false);
    setIsRhythmTrainingModalOpen(false);
    setIsRhythmSettingModalOpen(false);
    setSelectedSettingMode('none');
    setIsSoundPanelOpen(false);
  };

  // Check if any modal is open
  const isAnyModalOpen = isTimeSignatureModalOpen || isNoteSubdivisionModalOpen || 
                        isRhythmTrainingModalOpen || isRhythmSettingModalOpen || isSoundPanelOpen;

  // Training status text
  const statusText = getStatusText();

  return (
    <div
      style={{
        width: "100%",
        maxWidth: "100%",
        minHeight: "100vh",
        background: "var(--bg-primary)",
        overflowX: "hidden",
        overflowY: "hidden",
        margin: "0 auto",
        padding: "0",
        boxSizing: "border-box",
        ...commonFontStyle,
      }}
    >
      <div
        style={{
          width: "100%",
          height: "100vh",
          position: "relative",
          boxSizing: "border-box",
          ...commonFontStyle,
        }}
      >
        {/* Hamburger button for sound settings */}
        <HamburgerButton 
          isOpen={isSoundPanelOpen}
          onClick={() => setIsSoundPanelOpen(!isSoundPanelOpen)}
        />

        {/* Sound settings panel */}
        {isSoundPanelOpen && (
          <div
            style={{
              position: "fixed",
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              backgroundColor: "rgba(0, 0, 0, 0.4)",
              zIndex: 2000,
              backdropFilter: "blur(4px)"
            }}
            onClick={(e) => {
              if (e.target === e.currentTarget) {
                setIsSoundPanelOpen(false);
              }
            }}
          >
            <div
              style={{
                position: "absolute",
                top: 0,
                right: 0,
                width: "100%",
                maxWidth: "400px",
                height: "100%",
                backgroundColor: "var(--bg-primary)",
                overflowY: "auto",
                padding: "60px 0 20px 0",
                boxShadow: "-4px 0 20px rgba(0, 0, 0, 0.1)"
              }}
            >
              <SoundSettingsPanel />
            </div>
          </div>
        )}
        {/* Top: Beat visualization - 80px */}
        <div style={{ 
          position: "absolute",
          top: "80px",
          left: "16px",
          right: "16px",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          width: "calc(100% - 32px)"
        }}>
          <MTempoVisualizer
            beatCount={timeSignature.numerator}
            currentBeat={currentBeat}
            beatPattern={getBeatPattern() as (0 | 1 | 2 | 'A')[]}
          />
        </div>

        {/* Center: Control button area - 180px */}
        <div style={{ 
          position: "absolute",
          top: "180px",
          left: 0,
          right: 0,
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          width: "100%",
          zIndex: isAnyModalOpen ? 1001 : 1
        }}>
          <div style={{
            display: "flex",
            gap: "65px",
            alignItems: "center",
            justifyContent: "center"
          }}>
            <TimeSignatureButton 
              currentSignature={timeSignature}
              onSignatureChange={setTimeSignature}
              onClick={handleTimeSignatureClick}
            />
            
            <NoteSubdivisionButton 
              ref={rhythmSubdivBtnRef}
              onClick={handleNoteSubdivisionClick}
              currentRhythmId={selectedRhythmId}
            />
            
            <RhythmTrainingButton 
              onClick={handleRhythmTrainingClick}
              activeMode={activeMode}
            />
          </div>
        </div>

        {/* Training status display */}
        {activeMode !== 'none' && statusText && (
          <div style={{
            position: "absolute",
            top: "280px",
            left: 0,
            right: 0,
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            gap: "8px",
          }}>
            <div style={{
              background: "var(--bg-secondary, #f8f9fa)",
              border: "1px solid var(--DARK_GRAY)",
              borderRadius: "20px",
              padding: "8px 16px",
              fontSize: "14px",
              color: "var(--text-secondary)",
              fontWeight: "500"
            }}>
              {statusText}
            </div>
          </div>
        )}

        {/* Song info display (only in default mode) */}
        {activeMode === 'none' && (
          <div style={{
            position: "absolute",
            top: "280px",
            left: 0,
            right: 0,
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            gap: "8px",
          }}>
            <div style={{
              width: "24px",
              height: "24px",
              fontSize: "16px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center"
            }}>
              🎹
            </div>
            <span style={{
              fontSize: "16px",
              color: "var(--text-primary)",
              fontWeight: "normal"
            }}>
              Practice Session
            </span>
          </div>
        )}

        {/* Center: BPM dial - 350px */}
        <div style={{ 
          position: "absolute",
          top: "350px",
          left: 0,
          right: 0,
          display: "flex", 
          justifyContent: "center", 
          alignItems: "center",
          width: "100%"
        }}>
          <DialComponent
            currentBPM={bpm}
            isPlaying={isPlaying}
            onBPMChange={handleBpmChange}
            onPlayToggle={handleTogglePlay}
            enableDrag={true}
            enableKeyboard={true}
          />
        </div>

        {/* TapTempo button - mirrored position to the right of Play button */}
        <div style={{ 
          position: "absolute",
          top: "355px",
          left: 0,
          right: 0,
          display: "flex", 
          justifyContent: "center", 
          alignItems: "center",
          width: "100%",
          pointerEvents: "none"
        }}>
          <div style={{
            position: "relative",
            width: "180px",
            height: "180px",
            pointerEvents: "none"
          }}>
            <div style={{
              position: "absolute",
              bottom: "-40px",
              right: "-40px",
              pointerEvents: "auto",
              zIndex: isAnyModalOpen ? 999 : 1002
            }}>
              <TapTempoButton onClick={handleTapTempoClick} />
            </div>
          </div>
        </div>
      </div>

      {/* Time signature modal */}
      <TimeSignatureModal
        isOpen={isTimeSignatureModalOpen}
        onClose={handleModalClose}
        currentSignature={timeSignature}
        onConfirm={handleTimeSignatureConfirm}
        anchorTop={230}
      />

      {/* Rhythm subdivision modal */}
      <NoteSubdivisionModal
        isOpen={isNoteSubdivisionModalOpen}
        onClose={handleModalClose}
        onSelect={handleRhythmSelect}
        anchorTop={230}
        currentRhythmId={selectedRhythmId}
      />

      {/* Rhythm training option selection modal */}
      <RhythmTrainingModal
        isOpen={isRhythmTrainingModalOpen && !isRhythmSettingModalOpen}
        onClose={handleModalClose}
        onSelectMode={handleRhythmModeSelect}
        anchorTop={230}
      />

      {/* Rhythm training settings modal */}
      <RhythmSettingModal
        isOpen={isRhythmSettingModalOpen && !isRhythmTrainingModalOpen}
        onClose={() => {
          setIsRhythmSettingModalOpen(false);
          setSelectedSettingMode('none');
        }}
        mode={selectedSettingMode}
        songLengthSettings={songLength}
        incrementalTempoSettings={incrementalTempo}
        mutePatternSettings={mutePattern}
        onSongLengthChange={handleSongLengthChange}
        onIncrementalTempoChange={handleIncrementalTempoChange}
        onMutePatternChange={handleMutePatternChange}
        currentBPM={bpm}
        anchorTop={230}
      />

      <style>
        {`
          @keyframes pulse {
            0% {
              opacity: 1;
              transform: scale(1);
            }
            50% {
              opacity: 0.5;
              transform: scale(1.2);
            }
            100% {
              opacity: 1;
              transform: scale(1);
            }
          }
        `}
      </style>
    </div>
  );
}

export default Metronome;